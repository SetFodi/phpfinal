<?php
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $stmt = $mysqli->prepare('INSERT INTO records (name, email) VALUES (?, ?)');
    $stmt->bind_param('ss', $name, $email);
    $stmt->execute();
    $stmt->close();

    header('Location: index.php');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Record</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
<div class="container">
    <h2>Create Record</h2>
    <form method="post">
        <label>Name:</label>
        <input type="text" name="name" required>
        <label>Email:</label>
        <input type="email" name="email" required>
        <input type="submit" value="Create">
    </form>
</div>
</body>
</html>
