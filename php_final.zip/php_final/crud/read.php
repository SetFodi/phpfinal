<?php
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$id = $_GET['id'];
$stmt = $mysqli->prepare('SELECT * FROM records WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$record = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Read Record</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
<div class="container">
    <h2>Read Record</h2>
    <p>ID: <?php echo htmlspecialchars($record['id']); ?></p>
    <p>Name: <?php echo htmlspecialchars($record['name']); ?></p>
    <p>Email: <?php echo htmlspecialchars($record['email']); ?></p>
    <a href="index.php">Back</a>
</div>
</body>
</html>
