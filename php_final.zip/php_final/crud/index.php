<?php
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$result = $mysqli->query('SELECT * FROM records');
$records = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD Application</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
<div class="container">
    <header>
        <div id="branding">
            <h1>CRUD Application</h1>
        </div>
        <nav>
            <ul>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <h2>Records</h2>
    <a href="create.php">Add Record</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($records as $record): ?>
            <tr>
                <td><?php echo htmlspecialchars($record['id']); ?></td>
                <td><?php echo htmlspecialchars($record['name']); ?></td>
                <td><?php echo htmlspecialchars($record['email']); ?></td>
                <td>
                    <a href="read.php?id=<?php echo $record['id']; ?>">Read</a>
                    <a href="update.php?id=<?php echo $record['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $record['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
