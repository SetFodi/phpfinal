<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $upload_dir = 'uploads/';
    $file_name = basename($_FILES['file']['name']);
    $target_file = $upload_dir . $file_name;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        $stmt = $mysqli->prepare('INSERT INTO files (file_name, file_path) VALUES (?, ?)');
        if ($stmt) {
            $stmt->bind_param('ss', $file_name, $target_file);
            if ($stmt->execute()) {
                $success = "File uploaded successfully!";
            } else {
                $error = "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "Error: " . $mysqli->error;
        }
    } else {
        $error = "Error uploading file.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload File</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h2>Upload File</h2>
    <?php if (isset($error)): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <?php if (isset($success)): ?>
        <p class="success"><?php echo htmlspecialchars($success); ?></p>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <label>Choose a file:</label>
        <input type="file" name="file" required><br>
        <input type="submit" value="Upload">
    </form>
</div>
</body>
</html>
