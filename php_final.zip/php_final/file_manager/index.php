<!DOCTYPE html>
<html>
<head>
    <title>File Manager</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .container {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        a {
            display: block;
            margin: 10px 0;
            text-decoration: none;
            color: #007bff;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>File Manager</h2>
    <a href="upload.php">Upload File</a>
    <a href="list_files.php">List Files</a>
</div>
</body>
</html>
