<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $mysqli->prepare('SELECT * FROM files WHERE id = ?');
    if ($stmt) {
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $file = $result->fetch_assoc();
        $stmt->close();
    } else {
        die('Error: ' . $mysqli->error);
    }

    if ($file) {
        $file_path = $file['file_path'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        $stmt = $mysqli->prepare('DELETE FROM files WHERE id = ?');
        if ($stmt) {
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            header('Location: list_files.php');
            exit();
        } else {
            die('Error: ' . $mysqli->error);
        }
    } else {
        die('File not found in database.');
    }
} else {
    die('No file ID specified.');
}
?>
