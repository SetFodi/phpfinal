<?php
include 'config.php';

$result = $mysqli->query('SELECT * FROM files ORDER BY uploaded_at DESC');
$files = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>List Files</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h2>Uploaded Files</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>File Name</th>
            <th>Uploaded At</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($files as $file): ?>
            <tr>
                <td><?php echo htmlspecialchars($file['id']); ?></td>
                <td><?php echo htmlspecialchars($file['file_name']); ?></td>
                <td><?php echo htmlspecialchars($file['uploaded_at']); ?></td>
                <td>
                    <a href="read_file.php?id=<?php echo $file['id']; ?>">Read</a>
                    <a href="delete_file.php?id=<?php echo $file['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
