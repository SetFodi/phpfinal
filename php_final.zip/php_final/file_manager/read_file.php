<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $mysqli->prepare('SELECT * FROM files WHERE id = ?');
    if ($stmt) {
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $file = $result->fetch_assoc();
        $stmt->close();
    } else {
        die('Error: ' . $mysqli->error);
    }

    if ($file) {
        $file_path = $file['file_path'];
        if (file_exists($file_path)) {
            $content = file_get_contents($file_path);
        } else {
            die('File not found.');
        }
    } else {
        die('File not found in database.');
    }
} else {
    die('No file ID specified.');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Read File</title>
    <style>
        .container { width: 600px; margin: 0 auto; }
        pre { border: 1px solid #ccc; padding: 10px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Read File</h2>
    <pre><?php echo htmlspecialchars($content); ?></pre>
</div>
</body>
</html>
