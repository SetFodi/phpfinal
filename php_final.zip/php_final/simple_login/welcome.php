<?php
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $mysqli->prepare('SELECT email FROM users WHERE id = ?');
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
} else {
    echo "Error: " . $mysqli->error;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<div class="container">
    <h2>Welcome</h2>
    <p>Hello, <?php echo htmlspecialchars($user['email']); ?>!</p>
    <a href="logout.php">Logout</a>
</div>
</body>
</html>
