<?php
session_start();

$host = 'localhost';
$db = 'simple_login';
$user = 'root';
$pass = '';

// Create connection
$mysqli = new mysqli($host, $user, $pass, $db);

// Check connection
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}
?>
